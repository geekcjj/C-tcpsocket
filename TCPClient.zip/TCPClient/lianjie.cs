﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace TCPClient
{
    public partial class lianjie : Form
    {
        private delegate void ShowStatus(string str);
        private ShowStatus showStatusCallBack;
        private TcpClient tcpClient = null;
        private NetworkStream networkStream = null;
        private BinaryReader reader;
        private BinaryWriter writer;
        public event EventHandler GetValue;
        public string s1
        {
            get { return txtIp.Text; }
            set { txtIp.Text = value;}
        }
        public string s2
        {
            get { return txtPort.Text; }
            set { txtPort.Text = value; }
        }
        public lianjie()
        {
            InitializeComponent();
            //显示消息
            showStatusCallBack = new ShowStatus(showStatus);
        }

        private void lianjie_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtIp_TextChanged(object sender, EventArgs e)
        {
        }
        //显示状态
        private void showStatus(string str)
        {
            toolStripStatusLabel1.Text = str;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            txtIp.Text.Clone();
            txtPort.Text.Clone();
            this.Hide();
        }
        // 断开连接
        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            txtIp.Clear();
            txtPort.Clear();
           /* if (reader != null)
            {
                reader.Close();
            }
            if (writer != null)
            {
                writer.Close();
            }
            if (tcpClient != null)
            {
                // 断开连接
                tcpClient.Close();
            }

            statusStrip1.Text = "断开连接";*/
        }

        private void txtPort_TextChanged(object sender, EventArgs e)
        {

        }
        /*public void lianjie_FormClosing(Object sender,EventArgs e){
            if (GetValue != null)
            {
                String s1 = txtIp.Text;
                String s2 = txtPort.Text;
                GetValue(s1, e);
                GetValue(s2, e);
            }
        }*/

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
