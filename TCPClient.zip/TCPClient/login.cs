﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TCPClinet
{
    public partial class Form2 : Form
    {
        public delegate void DataChangeHandler(object sender, DataChangeEventArgs args);
        // 声明事件
        public event DataChangeHandler DataChange;
        //调用事件函数
        public void OnDataChange(object sender, DataChangeEventArgs args)
        {
            if(DataChange != null)
            {
                DataChange(this,args);
            }
        }
        public Form2()
        {
            InitializeComponent();
            Random rand = new Random();
            int a = ((int)Math.Floor(rand.NextDouble() * (10000 - 1)) + 1);
            txtyzm.Text = a.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonlogin_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "123" && textBox2.Text == "456"&&textBox3.Text==txtyzm.Text)
            {
                MessageBox.Show("用户登录成功！","提示");
                this.Hide();
                frmSyncTCPClient form1 = new frmSyncTCPClient();
                form1.Show();
            }
            else  
            {
                MessageBox.Show("输入错误！","警告");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            //当光标位于文本框时 如果用户按下了键盘上的Enter键
            if (e.KeyCode == Keys.Enter)
            {
                textBox2.Focus();
            }
        }
        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            //当光标位于文本框时 如果用户按下了键盘上的Enter键
            if (e.KeyCode == Keys.Enter)
            {
                textBox3.Focus();
            }
        }
        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            //当光标位于文本框时 如果用户按下了键盘上的Enter键
            if (e.KeyCode == Keys.Enter)
            {
                this.button1.Focus();
                buttonlogin_Click(this, new EventArgs());//调用登录事件
            }
        }
        private void label4_Click(object sender, EventArgs e)
        { Random rand = new Random();
            int a = ((int)Math.Floor(rand.NextDouble() * (10000 - 1)) + 1);
            txtyzm.Text = a.ToString();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            Rectangle rect = new Rectangle();
            rect = Screen.GetWorkingArea(this);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }
    }

    public class DataChangeEventArgs
    {
    }
}
