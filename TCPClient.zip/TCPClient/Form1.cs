﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using TCPClient;

namespace TCPClinet
{
    public partial class frmSyncTCPClient : Form
    {
        #region 变量
        // 申明变量
        private TcpClient tcpClient = null;
        private NetworkStream networkStream = null;
        private BinaryReader reader;
        private BinaryWriter writer;
        private Point _Location = new Point(0, 0);

        // 申明委托
        // 显示消息
        private delegate void ShowMessage(string str);
        private ShowMessage showMessageCallback;
        // 显示状态
        private delegate void ShowStatus(string str);
        private ShowStatus showStatusCallBack;
        
        // 清空消息
        private delegate void ResetMessage();
        private ResetMessage resetMessageCallBack;
        Thread threadclient = null;
        private const int bufferSize = 8000;
        public delegate void showData(string msg);
        private bool _isConnected = false;
        public bool IsConnected
        {
            get
            {
                return _isConnected;
            }
            set { _isConnected = value; }
        }
        #endregion
        public frmSyncTCPClient()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            #region 实例化委托

            // 显示状态
            showStatusCallBack = new ShowStatus(showStatus);       

            // 重置消息
            resetMessageCallBack = new ResetMessage(resetMessage);
            #endregion               
        }
        List<IPEndPoint> mlist = new List<IPEndPoint>();

        #region 定义回调函数

        // 显示消息
        /*private void showMessage(string str)
        {
            lstbxMessageView.Items.Add(tcpClient.Client.RemoteEndPoint);
            lstbxMessageView.Items.Add(str);
            lstbxMessageView.TopIndex = lstbxMessageView.Items.Count - 1;
        }*/
        // 显示状态
        private void showStatus(string str)
        {
            toolStripStatusInfo.Text = str;
        }
         
        // 清空消息
        private void resetMessage()
        {
            tbxMessage.Text = "";
            tbxMessage.Focus();
        }

        #endregion 

        #region 点击事件方法
        // 连接服务器方法,建立连接的过程
        private void ConnectToServer()
        {
                try
                {
                    // 调用委托
                    statusStripInfo.Invoke(showStatusCallBack, "正在连接...");
                    if (txtip.Text == string.Empty || txtport.Text == string.Empty)
                    {
                        MessageBox.Show("请先输入服务器的IP地址和端口号");
                    }

                    IPAddress ipaddress = IPAddress.Parse(txtip.Text);
                    tcpClient = new TcpClient();
                    tcpClient.Connect(ipaddress, int.Parse(txtport.Text));

                    // 延时操作
                    Thread.Sleep(1000);
                    if (tcpClient != null)
                    {
                        statusStripInfo.Invoke(showStatusCallBack, "连接成功");
                        networkStream = tcpClient.GetStream();
                        reader = new BinaryReader(networkStream);
                        writer = new BinaryWriter(networkStream);
                    }
                    threadclient = new Thread(recv);
                    threadclient.IsBackground = true;
                    threadclient.Start();
                }
                catch
                {
                    statusStripInfo.Invoke(showStatusCallBack, "连接失败");
                    Thread.Sleep(1000);
                    statusStripInfo.Invoke(showStatusCallBack, "就绪");
                   
                }

        }
        // 接受消息
        private void recv()
        {
            statusStripInfo.Invoke(showStatusCallBack,"接受中");
            while (true) {
                try
                {
                    //string receivemessage = reader.ReadString();
                    //lstbxMessageView.Invoke(showMessageCallback, receivemessage);
                    int readSize;
                    byte[] buffer = new byte[bufferSize];
                    lock (networkStream)
                    {
                        readSize = networkStream.Read(buffer, 0, bufferSize);
                    }
                    if (readSize == 0)
                        return;
                    //string returnStr = "";
                    //returnStr=Encoding.ASCII.GetString(buffer,0,bufferSize);
                    int str1 = BitConverter.ToInt32(buffer, 0);
                    //int intType = int.Parse(returnStr);rtbtxtShowData.Invoke(new showData(rtbtxtShowData.AppendText),
                    rtbtxtShowData.Text = str1.ToString("D5");
                }
                
            catch
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (writer != null)
                {
                    writer.Close();
                }
                if (tcpClient != null)
                {
                    tcpClient.Close();
                }
                statusStripInfo.Invoke(showStatusCallBack, "断开了连接");
                Thread.Sleep(2000);
                Thread connectThread = new Thread(ConnectToServer);
                connectThread.Start();
            }
            }
        }
        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            if (reader != null)
            {
                reader.Close();
            }
            if (writer != null)
            {
                writer.Close();
            }
            if (tcpClient != null)
            {
                tcpClient.Close();
            }
            toolStripStatusInfo.Text = "断开连接";
        }
        //获取当前系统时间
        private DateTime GetCurrentTime()
        {
            DateTime currentTime = new DateTime();
            currentTime = DateTime.Now;
            return currentTime;
        }
        // 关闭窗口
        private void btnClose_Click(object sender, EventArgs e)
        {
            //this.Close();
        }

        // 发送消息
        private void btnSend_Click(object sender, EventArgs e)
        {
            //调用ClientSendMsg方法 将文本框中输入的信息发送给服务端 
                Thread sendThread = new Thread(SendMessage);
                sendThread.Start(tbxMessage.Text);
                
        }
        private static byte[] hexstringtobytearray(string s)
        {
            s = s.Replace("","");
            byte[] by = new byte[s.Length / 2];
            for (int i = 0; i < s.Length; i += 2)
                by[i / 2] = (byte)Convert.ToByte(s.Substring(i, 2), 16);
            return by;
        }
        private void SendMessage(object state)
        {
            statusStripInfo.Invoke(showStatusCallBack, "正在发送...");
                try
                {
                    string str = state.ToString();
                    //int i10 = int.Parse(str);
                    //string str16 = i10.ToStringren("X2");
                    //char[] ch = str16.ToCharArray();
                    //byte[] by = Encoding.Default.GetBytes(str);
                    //int it1 = BitConverter.ToInt32(by,0);
                    /*int it =int.Parse(str);
                    string str16 = it.ToString("X2");
                    List<byte> bytes = new List<byte>();
                    byte a = Byte.Parse(str16);
                    bytes.Add(a);
                    byte[] by = bytes.ToArray();*/
                    byte[] array = hexstringtobytearray(str);
                    writer.Write(array); //发送就是写入输出流||Convert.ToString(BitConverter.ToInt16(Encoding.UTF8.GetBytes(str), 0), 16)
                    Thread.Sleep(3000);
                    writer.Flush();
                    statusStripInfo.Invoke(showStatusCallBack, "完毕");
                    tbxMessage.Invoke(resetMessageCallBack, null);
                    //lstbxMessageView.Invoke(showMessageCallback,state.ToString());
                    //将输入的内容字符串转换为机器可以识别的字节数组   
                    //byte[] arrClientSendMsg = Encoding.UTF8.GetBytes(sendMsg);
                    //调用客户端套接字发送字节数组   
                    //socketclient.Send(arrClientSendMsg);
                    //将发送的信息追加到聊天内容文本框中   
                    //lstbxMessageView..AppendText("客户端"+ ": " + GetCurrentTime() + "\r\n" + sendMsg + "\r\n\n");
                }
                catch
                {
                    if (reader != null)
                    {
                        reader.Close();
                    }
                    if (writer != null)
                    {
                        writer.Close();
                    }
                    if (tcpClient != null)
                    {
                        tcpClient.Close();
                    }
                    statusStripInfo.Invoke(showStatusCallBack, "断开了连接");
                    Thread connectThread = new Thread(ConnectToServer);
                    connectThread.Start();
                    Thread sendThread = new Thread(SendMessage);
                    sendThread.Start(tbxMessage.Text);
                }
        }
        // 清空消息
        private void btnClear_Click(object sender, EventArgs e)
        {
        }

        #endregion

        private void tbxMessage_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmSyncTCPClient_Load(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
        }

        private void lstbxMessageView_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void tbxserverIp_TextChanged(object sender, EventArgs e)
        {

        }
        private void tbxPort_TextChanged(object sender, EventArgs e)
        {

        }
        private void tbxMessage_KeyDown(object sender, KeyEventArgs e)
        {
            //当光标位于文本框时 如果用户按下了键盘上的Enter键
            if (e.KeyCode == Keys.Enter)
            {
                object state = null;
                //则调用客户端向服务端发送信息的方法  
                SendMessage(state.ToString());
                tbxMessage.Clear();
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("是否退出？选否,最小化到托盘", "操作提示", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Dispose();
            }
            else if (result == DialogResult.Cancel)
            {
                e.Cancel = true;

            }
            else
            {
                e.Cancel = true;
                this.WindowState = FormWindowState.Minimized;
                this.Visible = false;
                //this.notifyIcon1.Visible = true;
                this.ShowInTaskbar = false;
            }
        }
        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            base.Visible = true;
            //this.notifyIcon1.Visible = false;
            this.ShowInTaskbar = true;
            base.Show();
            base.WindowState = FormWindowState.Normal;
        }
        private void toolStripStatusInfo_Click(object sender, EventArgs e)
        {

        }

        private void statusStripInfo_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void lstbxMessageView_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtip_Click(object sender, EventArgs e)
        {

        }

        private void txtport_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            // 通过一个线程发起请求,多线程           
            Thread connectThread = new Thread(ConnectToServer);
            connectThread.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.panel1.Visible = false;
            this.panel2.Visible = true;
            this.panel2.BringToFront();
            this.panel2.Show();

        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.panel1.Visible = true;
            this.panel2.Visible = false;
            this.panel1.BringToFront();
            this.panel1.Show();
        }

        private void trackBar1_Scroll(object sender,EventArgs e)
        {
            tbar.Text = trackBar1.Value.ToString();
            String bar1=trackBar1.Value.ToString("X2");
            int bar2 = Convert.ToInt32(bar1, 16);
            Thread snedThread1 = new Thread(SendMessage);
            snedThread1.Start(bar2.ToString());
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void rtbtxtShowData_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            lianjie lianjie = new lianjie();
            //lianjie.GetValue += new EventHandler(SendValue);
            lianjie.ShowDialog();
            if (lianjie.DialogResult == DialogResult.OK)
            {
                txtip.Text = lianjie.s1;
                txtport.Text = lianjie.s2;
                //Thread receiveThread = new Thread(receiveMessage);
                //receiveThread.Start();
                lianjie.Close();
            }
            lianjie.Close();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            lianjie lianjie = new lianjie();
            //lianjie.GetValue += new EventHandler(SendValue);
            lianjie.ShowDialog();
            if (lianjie.DialogResult == DialogResult.OK)
            {
                txtip.Text = lianjie.s1;
                txtport.Text = lianjie.s2;
                //Thread receiveThread = new Thread(receiveMessage);
                //receiveThread.Start();
                lianjie.Close();
            }
            lianjie.Close();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
        }

        private void tbar_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            lianjie lianjie = new lianjie();
            //lianjie.GetValue += new EventHandler(SendValue);
            lianjie.ShowDialog();
            if (lianjie.DialogResult == DialogResult.OK)
            {
                txtip.Text = lianjie.s1;
                txtport.Text = lianjie.s2;
                //Thread receiveThread = new Thread(receiveMessage);
                //receiveThread.Start();
                lianjie.Close();
            }
            lianjie.Close();
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            lianjie lianjie = new lianjie();
            //lianjie.GetValue += new EventHandler(SendValue);
            lianjie.ShowDialog();
            if (lianjie.DialogResult == DialogResult.OK)
            {
                txtip.Text = lianjie.s1;
                txtport.Text = lianjie.s2;
                //Thread receiveThread = new Thread(receiveMessage);
                //receiveThread.Start();
                lianjie.Close();
            }
            lianjie.Close();
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            lianjie lianjie = new lianjie();
            //lianjie.GetValue += new EventHandler(SendValue);
            lianjie.ShowDialog();
            if (lianjie.DialogResult == DialogResult.OK)
            {
                txtip.Text = lianjie.s1;
                txtport.Text = lianjie.s2;
                //Thread receiveThread = new Thread(receiveMessage);
                //receiveThread.Start();
                lianjie.Close();
            }
            lianjie.Close();
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            lianjie lianjie = new lianjie();
            //lianjie.GetValue += new EventHandler(SendValue);
            lianjie.ShowDialog();
            if (lianjie.DialogResult == DialogResult.OK)
            {
                txtip.Text = lianjie.s1;
                txtport.Text = lianjie.s2;
                //Thread receiveThread = new Thread(receiveMessage);
                //receiveThread.Start();
                lianjie.Close();
            }
            lianjie.Close();
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            lianjie lianjie = new lianjie();
            //lianjie.GetValue += new EventHandler(SendValue);
            lianjie.ShowDialog();
            if (lianjie.DialogResult == DialogResult.OK)
            {
                txtip.Text = lianjie.s1;
                txtport.Text = lianjie.s2;
                //Thread receiveThread = new Thread(receiveMessage);
                //receiveThread.Start();
                lianjie.Close();
            }
            lianjie.Close();
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            lianjie lianjie = new lianjie();
            //lianjie.GetValue += new EventHandler(SendValue);
            lianjie.ShowDialog();
            if (lianjie.DialogResult == DialogResult.OK)
            {
                txtip.Text = lianjie.s1;
                txtport.Text = lianjie.s2;
                //Thread receiveThread = new Thread(receiveMessage);
                //receiveThread.Start();
                lianjie.Close();
            }
            lianjie.Close();
        }
    }
}